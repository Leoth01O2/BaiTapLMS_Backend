<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>${product == null ? 'Thêm sản phẩm' : 'Sửa sản phẩm'}</title>
    <style>
        body{font-family:Arial;max-width:600px;margin:40px auto}
        label{display:block;margin-top:12px}
        input{width:100%;padding:8px;box-sizing:border-box}
        button{margin-top:15px;padding:8px 14px}
    </style>
</head>
<body>
<h2>${product == null ? 'Thêm sản phẩm' : 'Sửa sản phẩm'}</h2>
<form action="${pageContext.request.contextPath}/products" method="post">
    <input type="hidden" name="action" value="${product == null ? 'create' : 'update'}">
    <input type="hidden" name="id" value="${product.id}">

    <label>Tên sản phẩm</label>
    <input type="text" name="name" value="${product.name}" required>

    <label>Giá</label>
    <input type="number" name="price" min="0" step="0.01" value="${product.price}" required>

    <label>Số lượng</label>
    <input type="number" name="quantity" min="0" value="${product.quantity}" required>

    <button type="submit">Lưu</button>
    <a href="${pageContext.request.contextPath}/products">Hủy</a>
</form>
</body>
</html>
