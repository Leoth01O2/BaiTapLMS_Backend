<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Quản lý sản phẩm</title>
    <style>
        body{font-family:Arial;max-width:900px;margin:40px auto}
        table{width:100%;border-collapse:collapse;margin-top:20px}
        th,td{border:1px solid #ccc;padding:10px;text-align:left}
        th{background:#eee}
        a,button{padding:6px 10px;text-decoration:none}
        .top{margin-bottom:15px}
        form{display:inline}
    </style>
</head>
<body>
<h2>Danh sách sản phẩm</h2>
<div class="top">
    <a href="${pageContext.request.contextPath}/products?action=create">Thêm sản phẩm</a>
</div>
<table>
    <tr>
        <th>ID</th>
        <th>Tên sản phẩm</th>
        <th>Giá</th>
        <th>Số lượng</th>
        <th>Thao tác</th>
    </tr>
    <c:forEach var="product" items="${products}">
        <tr>
            <td>${product.id}</td>
            <td>${product.name}</td>
            <td>${product.price}</td>
            <td>${product.quantity}</td>
            <td>
                <a href="${pageContext.request.contextPath}/products?action=edit&id=${product.id}">Sửa</a>
                <form action="${pageContext.request.contextPath}/products" method="post" onsubmit="return confirm('Bạn có chắc muốn xóa sản phẩm này?')">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="${product.id}">
                    <button type="submit">Xóa</button>
                </form>
            </td>
        </tr>
    </c:forEach>
</table>
</body>
</html>
