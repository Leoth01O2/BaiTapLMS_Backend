Bài kiểm tra cuối module JSP & Servlet

1. Chạy database.sql trong MySQL.
2. Nếu MySQL có mật khẩu, sửa jdbcPassword trong ProductDAO.java.
3. Build: mvn clean package
4. Copy target/FinalExam.war vào thư mục webapps của Tomcat.
5. Mở: http://localhost:8080/FinalExam/

Trước khi nộp, đổi tên file zip thành:
[Mã_số_sinh_viên]_FinalExam.zip
