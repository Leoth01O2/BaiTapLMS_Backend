CREATE DATABASE IF NOT EXISTS product_management;
USE product_management;

CREATE TABLE IF NOT EXISTS products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(12,2) NOT NULL,
    quantity INT NOT NULL
);

INSERT INTO products(name, price, quantity) VALUES
('Laptop Acer Nitro 5', 18000000, 5),
('Chuột Logitech G102', 350000, 20),
('Bàn phím DareU EK87', 550000, 12);
